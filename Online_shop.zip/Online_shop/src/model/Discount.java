package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Discount {
    public static PreparedStatement st;
    public static ResultSet rs;
}
